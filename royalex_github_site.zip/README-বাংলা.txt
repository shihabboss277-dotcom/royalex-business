ROYALEX Business — GitHub Pages সেটআপ (বাংলা)

এই ZIP-এ index.html আছে। এটি একটি static website; লগইন ও ডেটাবেসের জন্য Supabase ব্যবহার করে।

১) GitHub-এ নতুন repository তৈরি করুন, যেমন: royalex-business
২) Repository-তে Add file → Upload files চাপুন।
৩) এই ZIP খুলে ভেতরের index.html ফাইলটি আপলোড করুন (ZIP ফাইলটি নিজে আপলোড করবেন না)।
৪) index.html খুলে Edit (পেন্সিল) চাপুন।
৫) ফাইলের নিচের দিকে এই দুই লাইন খুঁজুন:
   const SUPABASE_URL = "PASTE_YOUR_SUPABASE_PROJECT_URL_HERE";
   const SUPABASE_PUBLISHABLE_KEY = "PASTE_YOUR_SUPABASE_PUBLISHABLE_OR_ANON_KEY_HERE";
৬) আপনার ROYALEX Supabase project-এর URL এবং Publishable key (অথবা anon public key) বসিয়ে Commit changes করুন।
   ⚠️ service_role/secret key কখনো ব্যবহার করবেন না।
৭) Repository → Settings → Pages → Deploy from a branch → main / root → Save।
৮) GitHub Pages লিংক তৈরি হলে খুলে লগইন পরীক্ষা করুন।

গুরুত্বপূর্ণ:
- এই কোডে business_members টেবিলে লগইন করা user-এর user_id, role='admin', approved=true থাকতে হবে।
- products, customers, orders টেবিল এবং RLS policies আগে থেকে থাকতে হবে।
- যদি ROYALEX-এর আলাদা Supabase project না থাকে, অন্য প্রজেক্টের URL/key আন্দাজ করে বসাবেন না।
- GitHub Pages শুধু frontend host করে; নিরাপত্তা Supabase Auth ও RLS policies-এর ওপর নির্ভর করে।
- প্রথমবার চালানোর আগে URL/key বসানো আবশ্যক।
